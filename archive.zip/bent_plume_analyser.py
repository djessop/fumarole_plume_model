#!/usr/bin/env python3

"""
bent_plume_analyser.py

A set of utilities to analyse wind-affected (bent) plumes

Provides functions:
-------------------
- centroid_posn
    Locate the "centre of mass" and spread of a plume.
- plume_trajectory
- gaussian_profile
- calc_scale_factor
- image_extent
- pixel_to_world
- world_to_pixel
- show_scaled_image    
- open_plot_expt_image
    [No documentation currently available]
- dist_along_path
    Calculates the cumulative distance along the plume axis.
- plume_angle
    Calculates the plume angle at each point along its axis.
- initial_guess_at_axis
- rotate_image
    rotates an image by a given angle.
- true_location_width    
- path_from_smoothed_theta
- wacky_value
- extract_temperatures
- read_params_file
- save_params_file
- _line
- plume_analysis
"""
from scipy.io.matlab import loadmat
from scipy.interpolate import interp1d, splrep, splev
from scipy.optimize import curve_fit
from matplotlib.ticker import MultipleLocator

import numpy as np
import matplotlib.pyplot as plt
import json 
import os
import shutil


# scale_factor = 38.               # Conversion factor/[pix/cm]
thermography='/home/david/FieldWork/Soufriere-Guadeloupe/Thermography'

def centroid_posn(x, y, n=2):
    '''
    Locate the "centre of mass" and spread of a 1D profile, following [1]

    Parameters
    ----------
    x : array like
        the positions at which the data is sampled
    y : array like
        the array of data
    n : scalar (optional)
        Exponent to which data are raised, default is 2.

    Returns
    -------
    COM : float
        Centre of mass of the array y given by (x * y**n).sum() / (y**n).sum()

    References
    ----------
    [1] D. Contini, A.Donateo, D.Cesari, A.G.Robins (2011), "Comparison of 
    plume rise models against water tank experimental data for neutral and 
    stable cross flows", J. Wind Eng. Ind. Aerodyn., 99, pp. 539--553    
    '''
    x = np.array(x)
    y = np.array(y)

    return (x * y**n).sum() / (y**n).sum()


def plume_trajectory(image, n=2, theta=np.pi/2, scale_factor=1):
    """
    Locate the "centre of mass" and spread of a plume, following [1]

    Parameters
    ----------
    image : numpy-array like
        Plume image.
    n : scalar
        Exponent to which rows and cols are raised, default is 2.
    theta : float
        Initial plume angle.  Default is np.pi / 2 (starts vertically)
    scale_factor : float
        Scaling between pixels and real-world units.  Default is 1.

    Returns
    -------
    xbar, zbar : numpy-array like
        the centre of mass of the plume, following [1]
    x0, z0 : scalars
        Location of the vent in terms of the image offset 

    References
    ----------
    [1] D. Contini, A.Donateo, D.Cesari, A.G.Robins (2011), "Comparison of 
    plume rise models against water tank experimental data for neutral and 
    stable cross flows", J. Wind Eng. Ind. Aerodyn., 99, pp. 539--553
    """
    # Ensure that image is a numpy array
    image = np.array(image)

    # Start by running over the rows of the image by fitting a gaussian to
    # the intensity profile, until either the plume angle is less than 60
    # degrees, or the fitting routine fails.
    x, z = np.arange(image.shape[1]), np.arange(image.shape[0])
    xbar, xsig, zbar, zsig = [], [], [], []
    p0 = (.8, 50, 50)

    for pos, row in enumerate(image):
        if any(row):
            xbar.append(centroid_posn(x, row))
            zbar.append(pos)
            # try:
                # popt, pcov = curve_fit(gaussian_profile, x, row, p0)
                # xbar.append(popt[1])
                # xsig.append(popt[2])        
                # zbar.append(pos)
            if len(xbar) > 1:
                dx = np.abs(xbar[-1] - xbar[-2])
                dz = np.abs(zbar[-1] - zbar[-2])
                theta = np.arctan(np.divide(dz, dx))
            if theta < np.pi / 3: # 60 degrees...
                break
            # except RuntimeError:
            #     break
            
    # Split the plume image into what remains beyond the break point of the
    # previous loop.
    x0    = int(np.ceil(xbar[-1])) # Move to the next point to the right
    image = image[:, x0:]

    # Iterate over columns of the image, but only do so if the plume is
    # present at that location.
    p0 = (.8, image.shape[0] / 2, 50)
    for pos, col in enumerate(image.T):
        if any(col):
            # Calculate weighted mean and std dev over the col
            xbar.append(pos + x0)
            zbar.append(centroid_posn(z, col))
            # zsig.append(np.sqrt(((z - zbar[-1])**2 * col).sum() / col.sum()))
            # try:
            #     popt, pcov = curve_fit(gaussian_profile, z, col, p0)
            #     xbar.append(pos + x0)
            #     zbar.append(popt[1])
            # except RuntimeError:
            #     break
    xbar = np.array(xbar)
    zbar = np.array(zbar)
    x0 = (xbar[0], zbar[0])
    xbar = (xbar - x0[0]) / scale_factor
    zbar = (zbar - x0[1]) / scale_factor
    return xbar, zbar, x0
    

def gaussian_profile(x, offset, amplitude, loc, width):
    """
    Returns an offset gaussian profile defined by its amplitude, 
    """
    return offset + amplitude * np.exp(-.5 * ((x - loc) / width)**2)


def calc_scale_factor(params):
    try:
        dist_to_vent = params['dist_to_vent']
        IFOV         = params['IFOV']
    except KeyError: 
        raise Warning('One of "dist_to_vent", "IFOV" not in params')

    return 1. / (2 * dist_to_vent * np.arctan(IFOV / 2))  # pix/m


def image_extent(params):  #image_shape, scale_factor=1., vent_loc=None):
    """
    Returns the extent of the image given its shape, a scale_factor and
    centroid location.  These are taken to be 1 and 0, 0 by default.

    Parameters
    ----------
    image_shape : array or list-like
    scale_factor : float
    vent_loc : None or tuple
    """
    image_shape  = [1, 1]
    scale_factor = 1
    vent_loc     = None
    try:
        image_shape  = params['image_shape']
        scale_factor = params['scale_factor']
        vent_loc     = params['vent_loc']
    except KeyError:
        raise Warning('One of "image_shape", "scale_factor" or "vent_loc" '\
                      'missing from params')
    Ox, Oz = 0, 0
    if vent_loc is not None:
        Ox, Oz = vent_loc
    
    extent_in_pix = np.array([0, image_shape[1], image_shape[0], 0])
    extent = np.array([(extent_in_pix[:2] - Ox) / scale_factor,
                       (Oz - extent_in_pix[2:]) / scale_factor]).flatten()

    return extent


def pixel_to_world(p, params):
    """
    Returns "real-world" positions (in units of metres), with the vent at
    (0, 0).

    Parameters
    ----------
    p : list or array_like
    params : dict
        Contains the fields scale_factor, vent_loc, image_shape
    

    Returns
    -------
    world_p : array_like
        Cartesian positions in units of metres, with origin at vent

    See also
    --------
    world_to_pixel, initial_guess_at_axis
    """
    try:
        p            = np.array(p)
        scale_factor = params['scale_factor']
        vent_loc     = params['vent_loc']
        image_shape  = params['image_shape']
    except KeyError: 
        raise Warning('One of "scale_factor", "vent_loc" or "image_shape" '\
                      'not in params')

    # Transpose array if not Nx2
    if p.shape[1] != 2:
        p = p.T

    return (p - vent_loc) * [1, -1] / scale_factor
    

def world_to_pixel(world_p, params):
    """
    Transforms real-world positions within the image plane in terms of pixels, 
    i.e. the inverse of real_to_pixel.

    Parameters
    ----------
    world_p : array_like
    scale_factor : float
    vent_loc : array_like
    image_shape : array_like

    Returns
    -------
    pixel_p : array_like
        Positions in pixels (wrt TL corner of image)

    See also
    --------
    world_to_pixel
    """
    try:
        world_p      = np.array(world_p)
        scale_factor = params['scale_factor']
        vent_loc     = params['vent_loc']
        image_shape  = params['image_shape']
    except KeyError: 
        raise Warning('One of "scale_factor", "vent_loc" or "image_shape" '\
                      'not in params')

    # Transpose array if not Nx2
    if world_p.shape[1] != 2:
        world_p = world_p.T

    return vent_loc + world_p * [1, -1] * scale_factor

    
def show_scaled_image(image, params, ax=None, cmap=plt.cm.gray):
    """
    Plots an image, overlaying real-world extents as the axes (as seen in the
    image plane), returning the extents and axes information.
    """

    extent = image_extent(params)
    
    if ax is None:
        fig, ax = plt.subplots()

    im = ax.imshow(image, extent=extent, cmap=cmap)

    return extent, im, ax


def open_plot_expt_image(path, axes, scale_factor=1., exptNo=1,
                         ind=None, showPlot=True):
    """
    
    """
    fname = path + 'gsplume.mat'
    
    data = np.flipud(loadmat(fname)['gsplume'])
    xexp = loadmat(path + 'xcenter.mat')['xcenter'][0]
    zexp = loadmat(path + 'zcenter.mat')['zcenter'][0]
    
    # Invert the data image if the background is brighter than background
    # (supposing that the background dominates)
    if data.mean() > .5:
        data = 1. - data

    # Coordinates of the origin as the first points in (xexp, zexp)
    Ox, Oz = (xexp[0], zexp[0])
    # Now calculate the world extent of the data, using a conversion factor 
    # of 38 pixels to 1 cm.  There's probably some neater and more pythonic
    # way of calculating the world extent list but at least it works as is.
    extent_in_pix = [0, data.shape[1], 0, data.shape[0]]
    extent = np.array([(extent_in_pix[:2] - Ox) / scale_factor,
                       (Oz - extent_in_pix[2:]) / scale_factor])
    extent = extent.flatten().tolist()
    xexp   = (xexp - Ox) / scale_factor
    zexp   = (Oz - zexp) / scale_factor

    xbar, zbar, x0 = plume_trajectory(data, 2, np.pi/2, scale_factor)

    if ind is not None and len(axes) > 1:
        ax = axes[ind]
    else:
        ax = plt.gca() 

    im = ax.imshow(data, extent=extent, cmap=plt.cm.magma, zorder=0)
    ax.invert_yaxis()
    ax.plot(xexp, zexp, 'w-',  lw=2, label='GCTA centroid', zorder=3)
    ax.plot(xbar, zbar, 'w--', lw=2, label='my centroid', zorder=3)
    ax.set_title('Expt %2d' % exptNo, fontsize=10)

    if showPlot:
        plt.show()

    return ax, im, data, xexp, zexp, extent, (Ox, Oz)


def dist_along_path(x, y):
    """
    Returns a vector of the cumulative euclidian norms for input (x,y), i.e.
    the distance travelled along the path defined by the loci (x, y)

    """
    # Differences between consectutive points
    dx, dy = np.diff(x), np.diff(y)
    # The first point - assumes that x and y are measured with respect to
    # a well-defined origin
    s0 = np.sqrt(x[0]**2 + y[0]**2)
    # Add the first point to the cumulative sum of the differences
    return np.append(0, np.sqrt(dx**2 + dy**2).cumsum()) #+ s0


def plume_angle(x, y, errors=None):
    """
    Calculates the angle of a plume from the axis coordinates, (x,y), as
    $\theta = \atan(dy / dx)$.  Note that $\theta$ is measured relative to the 
    horizontal.

    parameters
    ----------
    x, y : array_like
        coordinates of the plume axis
    errors : tuple or array_like (optional)
        measurement errors on x and y.  If errors contains more than two 
        elements, an error will be raised.

    returns
    -------
    theta : array_like
        angle of the plume axis relative to the horizontal.  Positive angles 
        are measured in the anti-clockwise direction.
    sig_theta : array_like
        error associated with angle calculations

    see also
    --------
    numpy.arctan2
    """
    try:
        dy    = np.gradient(y, edge_order=2)
        dx    = np.gradient(x, edge_order=2)
        theta = np.arctan2(dy, dx)
    except ValueError:
        theta = None

    if errors is not None:
        denom     = dx**2 + dy**2
        dfdx      = dy / denom  # -ve ignored as dfdx squared when used
        dfdy      = dx / denom
        sig_theta = np.sqrt((dfdx * errors[0])**2 + (dfdy * errors[1])**2)
        return theta, sig_theta
    else:    
        return theta


def initial_guess_at_axis(N=50):
    """
    Get a maximum of N points from the current image
    """
    # If no input for p is given (i.e. p is None), p is an empty list, or
    # p is an empty array, or any entry in p is None, then initialise p.
    # or (type(p) is list and p == []) or (type(p) is np.ndarray
    # and p.size == 0) or if any(p == None):
    print('Click on the points that will form the initial guess')
    return np.array(plt.ginput(N)) # Max of N pts



def rotate_image(img, angle, pivot):
    '''
    Rotates an image by padding the edges by an amount equal to the 
    location of the pivot point.

    Parameters
    ----------
    img : 2d array (image)
        The 2D (greyscale) image to be rotated
    angle : scalar
        Angle (in degrees) through which the image will be rotated
    pivot : array_like
        Two-element point around which the image will be rotated

    Returns
    -------
    img_rot : 2D array (image)
        The rotated image
    '''
    from skimage.transform import rotate

    pad_x = [img.shape[1] - pivot[0], pivot[0]]
    pad_y = [img.shape[0] - pivot[1], pivot[1]]
    pad_w = np.array([pad_y, pad_x]).astype(int)
    row_trim, col_trim = np.array(img.shape) // 2
    # Add left and right padding to image so as to centre the pivot location.
    # Padded image will be twice the size of the initial image array.
    img_pad = np.pad(img, pad_w, 'edge')
    img_rot = rotate(img_pad, angle, resize=False, mode='edge')

    return img_rot[row_trim:2*img.shape[0]-row_trim,
                   col_trim:2*img.shape[1]-col_trim]


def true_location_width(data, mask=None, p=None, scale_factor=1,
                        errors=None, plotting=False, retrows=False):
    '''
    Returns the "true" location of the plume centroid for 

    Parameters
    ----------
    data : image (NDarray)
        The plume image to be analysed.
    mask : NDarray (optional)
        A mask to be applied to the image
    p : array_like (optional)
        A guess (initial or updated) as to the location of the plume axis.
        "p" should be given in pixel values
    scale_factor : float (optional)
        pixels per metre scale.  Default is 1.
    errors : array_like (optional)
        array of location measurement uncertainties, in pixels.  Default is
        None, resulting in the returned width uncertanties being purely a
        function of the inversion covariance matrix.
    plotting : bool (optional)
        plot the progression of the algorithm. Default is False
    retrows : bool (optional)
        return the rows of the rotated image from which the plume width is
        determined.  Default is False

    Returns
    -------
    true_locn : 2D array_like
        The "true" location of the plume centroid
    plume_width : 1D array_like
        The width at location trueLocn[i] and angle theta[i]
    sig_true_locn : 1D array_like
        Uncertainties associated with the plume location 
    sig_width : 1D array_like
        The std dev. of the plume width from fitting a gaussian to the plume
        intensity data at each point along its axis.
    rows : array_like
        The intensity data along an axis perpendicular to the plume motion.

    See also
    --------
    plume_angle
    '''
    if mask is None:
        mask = np.ones_like(data).astype(float)

    if p is None:
        p = initial_guess_at_axis()

    s = dist_along_path(*p.T)

    
    # Iterate through the selected points, rotating the image through 
    # the estimated angle and calculating the true location of the midpoint
    # at each point.
    h_window_offset = 250
    v_window_offset =   5
    true_locn, true_loc_err, plume_width, plume_width_err = [], [], [], []
    r2 = 0.

    if plotting:
        # fig1, axes1 = plt.subplots(1, 2)
        fig1 = plt.figure()
        ax00 = fig1.add_axes([.05,       .35, .4,        .6])
        ax01 = fig1.add_axes([.61724047, .35, .26551907, .6])
        ax10 = fig1.add_axes([.05,       .05, .4,        .2])
        ax11 = fig1.add_axes([.61724047, .05, .26551907, .2])

        ax00.imshow(data) #[::-1])
        ax00.plot(p[:,0], p[:,1], 'r+', lw=2)
        
        ax10.set_xlim((s.min(), s.max()))
        ax10.axhline(0., c='k', ls='--', lw=.5)
        ax10.set_title('$r^2$: %.4f' % r2)

    # Loop through the locations in p, rotating the image as required and
    # obtaining the maximum intensity and the half width of the plume
    # "section" at each location from a Gaussian fit.
    theta, sig_theta = plume_angle(*p.T, errors=[1 / scale_factor]*2)

    # print(f"$\\theta$ = {theta}")

    # Lists for the variance of b and d (from covariance matrix)
    var_b, var_d, d, rows = [], [], [], []

    for p_, th in zip(p, theta):
        im_r = rotate_image(data, 90-np.rad2deg(th), p_)  # data[::-1]
        ma_r = rotate_image(mask, 90-np.rad2deg(th), p_)  
        M, N = im_r.shape
        M_2  = M // 2

        # Define the plume section as the 2*v_window_offset+1 (~10) rows 
        # centred about the current location, and return the row-wise mean.
        rma  = ma_r[M_2-v_window_offset:M_2+v_window_offset+1].mean(axis=0)
        row  = im_r[M_2-v_window_offset:M_2+v_window_offset+1].mean(axis=0)
        #row -= row.mean() * rma
        row *= rma

        rows.append(row.tolist())
        # Fit a Gaussian to the data and use this to define plume parameters
        p0   = (0., row.max(), N/2, 50.)
        X = np.arange(len(row))
        popt, pcov = curve_fit(gaussian_profile, X, row, p0)
        plume_width.append(popt[-1])
        plume_width_err.append(np.sqrt(np.diag(pcov[-1])))
        var_b.append(pcov[-1][-1])
        # Distance from centre of plume to the centre of the row, in
        # rotated coordinates
        d.append(popt[2] - (N//2)) # COM - (N/2) #
        var_d.append(d[-1]**2 * pcov[2][2])
        # Add the distance (i.e. residual) squared to the R2 value
        r2 += d[-1]**2
        # Do some geometry to find the "true location" of the plume centre
        # Should the distance from COM be added or subtracted from estimated
        # plume axis locus?
        true_locn.append(np.float64(p_) -   # Should this be a + or -?
                        np.multiply(d[-1], [np.cos(th), np.sin(th)]))

        # ----------------------------------------------------------------- #
        # The remainder of this function is dedicated to plotting the
        # solutions.  Should probably incorporate a boolean handle that turns
        # this functionality on or off.
        # ----------------------------------------------------------------- #
        if plotting:
            # Plot the solution for visualisation purposes.
            # Update "true locations" on the base image
            ax00.plot(true_locn[-1][0], true_locn[-1][1], 'c+', ms=8, lw=3)
            
            # Rotate the image to show where current section is being calculated
            ax01.imshow(im_r)
            ax01.axvline(N/2)
            ax01.axvline(N/2 - h_window_offset, ls='--')
            ax01.axvline(N/2 + h_window_offset, ls='--')
            ax01.axhline(M/2)
            
            # Plot the residual as a function of distance along plume axis
            #ax10.plot(s, d[-1], '+', c='C0')
            #ax10.set_title('$r^2$: %.4f' % r2)
            
            # Plot the section for the current rotation
            ax11.clear()
            ax11.plot(X, row, '-', c='C0', label='data')
            ax11.plot(X, gaussian_profile(X, *popt), 'r-', label='gaussian')
            ax11.axvline(popt[2], c='r', ls='--', lw=2, zorder=1)
            ax11.axvline(N/2, c='C0', ls='-', zorder=0)
            ax11.axvline(N/2 - h_window_offset, c='C0', ls='--', zorder=0)
            ax11.axvline(N/2 + h_window_offset, c='C0', ls='--', zorder=0)
            plt.pause(.5)  # Pause for a crude animation
        #plt.close()

    # Convert lists to numpy arrays for ease of manipulation
    var_b = np.array(var_b)
    var_d = np.array(var_d)
    d = np.array(d)
    if errors is not None:
        sig_true_locn = np.sqrt(2 * errors[0]**2 + var_d + d**2 * sig_theta)
        if retrows:
            return (np.array(true_locn), np.abs(np.array(plume_width)),
                    sig_true_locn, np.sqrt(var_b), rows)
        else:
            return (np.array(true_locn), np.abs(np.array(plume_width)),
                    sig_true_locn, np.sqrt(var_b))
    elif errors is None:
        if retrows:
            np.array(true_locn), np.abs(np.array(plume_width)), rows
        else:  # default behaviour
            return np.array(true_locn), np.abs(np.array(plume_width))


def path_from_smoothed_theta(s, theta, snew, smoothing=0.): 
    '''
    Returns a smoothed version of the axis locus
    '''
    tck = splrep(s, theta, s=smoothing) 
    thetaNew = splev(snew, tck) 
    xnew, znew = [0], [0] 
    for ds, th in zip(np.diff(snew), thetaNew): 
        dx = ds * np.cos(th) 
        dz = ds * np.sin(th) 
        xnew.append(xnew[-1] + dx) 
        znew.append(znew[-1] + dz) 
    return np.array(xnew), np.array(znew), thetaNew


def wacky_value(val, sig_val, cutoff=.5):
    """filter values with rel. errors larger than cutoff value (default 50%)"""
    val, sig_val = np.abs(val), np.abs(sig_val)
    if np.all(sig_val / val > cutoff):
        return True
    return False


def extract_temperatures(params, rows=None, mode='max'):
    Texp, sig_Texp = [], []
    if rows is None:
        p     = np.array(params['trajectory'])
        sexp  = dist_along_path(*p.T)
        thexp = plume_angle(*p.T)
        rows  = []
    else:
        for row in rows:
            offs = row.mean()
            ampl = row.max()  
            locn = np.argmax(row)
            wide = 50
            p0   = (offs, ampl, locn, wide)
            x    = np.arange(len(row))
            try:
                popt, pcov = curve_fit(gaussian_profile, x, row, p0=p0)
                T, sig_T = popt[1], np.sqrt(pcov[1, 1])
                if wacky_value(T, sig_T):
                    Texp.append(np.nan)
                    sig_Texp.append(np.nan)
                else:
                    if mode != 'mean':
                        # max temperature is amplitude of gaussian curve
                        Texp.append(T)
                    else:
                        # mean taken to be value at 1/e width
                        Texp.append(0)
                    sig_Texp.append(sig_T)
            except:
                Texp.append(np.nan)
                sig_Texp.append(np.nan)
    return np.array(Texp), np.array(sig_Texp)


def read_params_file(params_file):
    import json

    with open(params_file, 'r') as f:
        params = json.load(f)

    return params


def save_params_file(params, params_file):
    from datetime import datetime as dt
    import json
    from os.path import getctime, isfile
    from shutil import copyfile

    dfmt = '%Y%m%d'
    timenow_str = dt.now().strftime(dfmt)
    timecrn_str = dt.fromtimestamp(getctime(params_file)).strftime(dfmt)
    todays_json = params_file + '.' + timecrn_str

    print(params_file, todays_json)

    if isfile(params_file) and not isfile(todays_json):
        copyfile(params_file, todays_json)
    with open(params_file, 'w') as f:
        params = json.dump(params, f)

    return 


def _line(x, y, th, width=.5):
    # print(th / np.pi)
    if abs(th/np.pi) < .25:
        width /= 10
    x_ = np.array([-width, width])
    y_ = (x_) / np.tan(th)
    return x_ + x, y_ + y


def plume_analysis(date, site, thermography=thermography):
    """
    Utility for extracting data from thermal images
    """
    from datetime import datetime as dt
    import tifffile
        
    path = '/'.join([thermography, date + '_' + site])
    im_path = path + '/' + date.replace('-', '') + '_' + site + '_imAve_bt.tif'
    data = tifffile.imread(im_path)
    # data = np.flipud(data)
    params_file = path + '/parameters.json'
    
    params = read_params_file(params_file)
    
    trajectory   = np.array(params['trajectory'])
    extent       = params['extent']
    scale_factor = params['scale_factor']
    
    vent_loc     = params['vent_loc']
    image_shape  = params['image_shape']
    
    extent       = image_extent(params)
    
    #trajectory   = np.array(trajectory)
    #trajectory[:,1] = image_shape[0] - trajectory[:,1]
    
    real_trajectory = pixel_to_world(trajectory, params)
    p = trajectory.copy()
    
    #####################
    # EXTRACT VARIABLES #
    #####################
    # thexp, sig_thexp = plume_angle(p[:,0], p[:,1], errors=[1/scale_factor]*2)
    # thexp[0] = np.pi/2

    true_loc, bexp, sig_p, \
        sig_bexp, rows = true_location_width(data,
                                             p=p,
                                             errors=[1/scale_factor],
                                             retrows=True)
    sexp = dist_along_path(*p.T)  #[:,0], p[:,1])
    Texp, sig_Texp = extract_temperatures(params, np.array(rows))

    ############
    # Plotting #
    ############
    fig, axes = plt.subplots(ncols=2, sharey=False)
    extent, im, ax = show_scaled_image(data, params, ax=axes[0])
    # ax.plot(0, 0, 'or')  # vent location
    
    ## DEFINE THE DISTANCE ALONG THE AXIS, THE ANGLE AND THE WIDTH OF THE PLUME
    # pPixels = p.copy() * scale_factor + vent_loc
    # pPixels *= [1, -1]
    # pPixels += [0, 2*n]

    # print(real_trajectory)
    ax.plot(*real_trajectory.T, '-.r', lw=.8)
    ax.set_xlabel('Horizontal distance/[m]')
    ax.set_ylabel('Vertical distance/[m]')
    ax.set_title('Time-averaged TIR image')
    ax.xaxis.set_minor_locator(MultipleLocator(1))
    ax.yaxis.set_minor_locator(MultipleLocator(1))
    
    thexp, sig_thexp = plume_angle(p[:,0], p[:,1], errors=[1/scale_factor]*2)
    _, bexp, sig_p, sig_bexp = true_location_width(data, p=p,
                                                   errors=[1/scale_factor])
    sexp      = dist_along_path(*real_trajectory.T)
    bexp     /= scale_factor
    sig_bexp /= scale_factor
    Texp     += 273.15

    mab           = sig_bexp / bexp > .5
    bexp[mab]     = np.nan
    sig_bexp[mab] = np.nan

    for th, p_ in zip(thexp, real_trajectory):
        xs, ys = p_
        x_, y_ = _line(xs, ys, th, width=.8)
        ax.plot(x_, y_, '--r', lw=.5)
    
    axes[1].errorbar(10 * bexp, sexp, ls='none', xerr=10 * sig_bexp,
                     marker='.', c='k', label=r'10 $\times$ Plume width/[m]')
    axes[1].errorbar(0.1*(Texp-273.15), sexp, ls='none', xerr=0.1*sig_Texp,
                     marker='.', c='C0', label=r'0.1 $\times$ Plume temp./[°C]')
    
    # axes[1].set_xlabel('Plume width/[m]')
    axes[1].set_ylabel('Distance along plume axis/[m]')
    axes[1].set_title('Plume parameters')
    axes[1].legend()
    
    fig.suptitle(f'{date}, {site}');
    fig.savefig(path + f'/{date}_{site}_analysis.png');

    ###############
    # UPDATE JSON #
    ###############
    params['real_trajectory'] = real_trajectory.tolist()
    params['sexp']      = sexp.tolist()
    params['bexp']      = bexp.tolist()
    params['Texp']      = Texp.tolist()
    params['thexp']     = thexp.tolist()
    params['sig_bexp']  = sig_bexp.tolist()
    params['sig_Texp']  = sig_Texp.tolist()
    params['sig_thexp'] = sig_thexp.tolist()

    todays_json = params_file + '.' + dt.now().strftime('%Y%m%d')
    if os.path.isfile(params_file):
        if not os.path.isfile(todays_json):
            shutil.copyfile(params_file, todays_json)
    save_params_file(params, params_file)

    return


if __name__ == '__main__':
    plt.close('all')    # Clear pre-existing plots

    # Set a path variable according to which experiment is required
    exptNo = 3
    path   = './data/ExpPlumes_for_Dai/exp%02d/' % exptNo
    #fname  = path + 'gsplume.mat'
    #path = '/home/ovsg/Documents/Thermographie/done/tiff/2019/mu sigma/'

    # Initial guesses.  Either load from file or make a fresh guess
    with open(path + 'exp%02d_initGuess.json' % exptNo) as f:
    #with open(path + '20190314_CSS_initGuess.json') as f:
        jsondata = json.load(f)
    p = np.array(jsondata['data'])

    scale_factor = 77.44015387936139
    
    fig, ax = plt.subplots()    
    try:
        axes = np.array([ax])
        ax, im, data, xexp, zexp, extent, (Ox, Oz) = open_plot_expt_image(path,
                                                                       axes),
                                                                       #exptNo)
        leg  = ax.legend()
        leg.get_frame().set_facecolor('gray')                                   
    except TypeError:
        raise Warning(f'file {fname} does not exist...skipping!')

    #p       = initial_guess_at_axis()  # Comment out if loading from file
    pPixels = p.copy() * scale_factor
    pPixels[:,0] += Ox
    pPixels[:,1] -= Oz
    pPixels[:,1] *= -1

    thexp, sig_thexp = plume_angle(*p.T, errors=[1/scale_factor]*2)
    _, bexp, sig_p, sig_bexp = true_location_width(pPixels, data,
                                                 errors=[1/scale_factor],
                                                 plotting=True)

    # Form the state variables that will be compared to model solution. 
    #p[:,0] = (p[:,0] - Ox) / scale_factor
    #p[:,1] = (Oz - p[:,1]) / scale_factor
    bexp     /= scale_factor
    sig_bexp /= scale_factor
    sig_p    /= scale_factor
    sexp = dist_along_path(p[:,0], p[:,1])
    Vexp = np.array([bexp, thexp]).T
    sigV = np.array([sig_bexp, sig_thexp]).T

    # fname  = './data/ExpPlumes_for_Dai/GCTA_plumeData.xlsx'
    # writer = pandas.ExcelWriter(fname, engine='xlsxwriter') 
